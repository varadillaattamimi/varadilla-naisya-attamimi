
"""
TUGAS PERSONAL 2 — Modifikasi Level 6–9
======================================

Setiap modifikasi menggunakan data pribadi mahasiswa dan menghasilkan
angka yang dapat dihitung ulang (deterministik).

Jalankan dari folder utama proyek:
    python tugas_personal_2/jalankan_tugas_2.py --cek
    python tugas_personal_2/jalankan_tugas_2.py

Catatan keamanan:
Kunci privat Level 7 hanya untuk latihan. Jangan pernah membuat kunci
keuangan sungguhan dari nama, NIM, atau tanggal lahir.
"""

import hashlib

from ecdsa import SECP256k1, SigningKey

import level06_difficulty as L6
import level07_tanda_tangan as L7
import level08_jaringan as L8
import level09_reward_saldo as L9


# ============================================================== MODIFIKASI 6
def jejak_difficulty(awal: int, daftar_waktu: list, target: float) -> list:
    """Terapkan penyesuaian difficulty untuk setiap waktu blok.

    Mengembalikan daftar difficulty setelah masing-masing penyesuaian.
    """
    difficulty = awal
    hasil = []

    for waktu_aktual in daftar_waktu:
        difficulty = L6.sesuaikan_difficulty(
            difficulty,
            waktu_aktual,
            target
        )
        hasil.append(difficulty)

    return hasil


# ============================================================== MODIFIKASI 7
def kunci_dari_data(nama: str, nim4: str, tanggal_lahir: str):
    """Buat pasangan kunci SECP256k1 deterministik dari data mahasiswa.

    PERINGATAN: hanya untuk latihan. Jangan gunakan cara ini untuk kunci asli.
    """
    bahan = f"{nim4}:{nama}:{tanggal_lahir}".encode("utf-8")
    digest = hashlib.sha256(bahan).hexdigest()
    secret = int(digest, 16) % SECP256k1.order

    if secret == 0:
        secret = 1

    sk = SigningKey.from_secret_exponent(
        secret,
        curve=SECP256k1
    )
    vk = sk.get_verifying_key()

    kunci_privat_hex = sk.to_string().hex()
    kunci_publik_hex = vk.to_string().hex()

    return kunci_privat_hex, kunci_publik_hex


def tanda_tangani_deterministik(tx: dict, kunci_privat_hex: str) -> str:
    """Tandatangani transaksi secara deterministik (RFC 6979)."""
    sk = SigningKey.from_string(
        bytes.fromhex(kunci_privat_hex),
        curve=SECP256k1
    )

    pesan = L7.pesan_transaksi(tx)
    tanda_tangan = sk.sign_deterministic(pesan)

    return tanda_tangan.hex()


# ============================================================== MODIFIKASI 8
class NodePersonal(L8.Node):
    """Node Level 8 yang menambahkan penanda nama dan NIM pada bloknya."""

    def __init__(self, nama: str, nim4: str, difficulty: int = 2):
        super().__init__(nama, difficulty)
        self.nim4 = nim4

    def tambang_blok(self, transactions) -> dict:
        penanda = f"{self.nama}#{self.nim4}"
        daftar_transaksi = [penanda] + list(transactions)
        return super().tambang_blok(daftar_transaksi)


def semua_sepakat(nodes: list) -> bool:
    """True jika semua node memiliki rantai yang sama persis."""
    if not nodes:
        return True

    rantai_acuan = nodes[0].chain
    return all(node.chain == rantai_acuan for node in nodes[1:])


# ============================================================== MODIFIKASI 9
class BlockchainHalving(L9.Blockchain):
    """Blockchain Level 9 dengan hadiah mining yang berkurang separuh berkala."""

    def __init__(self, hadiah_awal: int, interval: int, difficulty: int = 2):
        if hadiah_awal < 0:
            raise ValueError("hadiah_awal tidak boleh negatif")
        if interval <= 0:
            raise ValueError("interval harus lebih besar dari 0")

        super().__init__(difficulty)
        self.hadiah_awal = hadiah_awal
        self.interval = interval

    def hadiah(self, index: int) -> int:
        """Hitung hadiah blok berdasarkan jadwal halving."""
        if index < 1:
            raise ValueError("index blok harus minimal 1")

        jumlah_halving = (index - 1) // self.interval
        return self.hadiah_awal // (2 ** jumlah_halving)

    def mine(self, alamat_penambang: str) -> dict:
        """Tambang blok baru dengan coinbase sesuai jadwal halving."""
        index = self.chain[-1]["index"] + 1

        coinbase = {
            "sender": L9.SISTEM,
            "recipient": alamat_penambang,
            "amount": self.hadiah(index)
        }

        # Coinbase harus berada di posisi pertama.
        transactions = [coinbase] + self.pending_transactions.copy()

        last = self.chain[-1]
        block = {
            "index": index,
            "transactions": transactions,
            "previous_hash": last["hash"],
            "nonce": 0
        }

        self._tambang(block)
        self.chain.append(block)
        self.pending_transactions.clear()

        return block

    def validasi_ekonomi(self) -> bool:
        """Validasi suplai dan saldo dengan hadiah halving per nomor blok."""
        saldo = {}

        # Genesis tidak memiliki transaksi ekonomi.
        for block in self.chain[1:]:
            transactions = block["transactions"]

            # Setiap blok harus memiliki transaksi coinbase.
            if not transactions:
                return False

            coinbase = transactions[0]
            hadiah_seharusnya = self.hadiah(block["index"])

            # Coinbase harus berasal dari sistem dengan jumlah yang tepat.
            if (
                coinbase["sender"] != L9.SISTEM
                or coinbase["amount"] != hadiah_seharusnya
            ):
                return False

            # Tidak boleh ada transaksi sistem selain coinbase.
            for tx in transactions[1:]:
                if tx["sender"] == L9.SISTEM:
                    return False

            # Putar ulang seluruh transaksi secara berurutan.
            for tx in transactions:
                sender = tx["sender"]
                recipient = tx["recipient"]
                amount = tx["amount"]

                if amount <= 0:
                    return False

                if sender == L9.SISTEM:
                    saldo[recipient] = saldo.get(recipient, 0) + amount
                else:
                    saldo[sender] = saldo.get(sender, 0) - amount

                    # Saldo tidak boleh negatif.
                    if saldo[sender] < 0:
                        return False

                    saldo[recipient] = saldo.get(recipient, 0) + amount

        return True
