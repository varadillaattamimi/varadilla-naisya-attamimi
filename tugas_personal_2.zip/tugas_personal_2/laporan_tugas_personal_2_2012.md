# Laporan Tugas Personal 2 — Blockchain Level 6–9

- **Nama:** VARADILLA NAISYA ATTAMIMI
- **NIM (4 digit terakhir):** 2012
- **Dibuat:** 2026-11-14 17:58  (waktu proses 0.3 detik)
- **Kode verifikasi:** `5EC227ED0432`

> Bagian hasil dibuat otomatis. Jangan diubah: dosen menghitung ulang semua angka dari data Anda.
> Isi bagian **Analisis** dengan kata-kata Anda sendiri.

## Level 6 — Mining data pribadi dan jejak difficulty

Data yang ditambang: `VARADILLA NAISYA ATTAMIMI|2012|2005-11-18`

| Difficulty | Nonce | Percobaan | Teori 16^d | Hash |
|---|---|---|---|---|
| 1 | 15 | 16 | 16 | `048c4d3a260d3933d25e…` |
| 2 | 589 | 590 | 256 | `00b2fef71937cb9f9604…` |
| 3 | 3289 | 3.290 | 4.096 | `0008e4f826d69c7b16e3…` |
| 4 | 71860 | 71.861 | 65.536 | `00007a1e7f360c77dfbd…` |

- Difficulty awal (dari NIM): **1**, target waktu blok 10 detik
- Waktu blok simulasi (dari NIM + tanggal + bulan lahir): 8, 0, 4, 8, 4, 32, 4, 4 detik
- Jejak difficulty (Modifikasi 6): **1, 2, 3, 3, 4, 3, 4, 5**

## Level 7 — Kunci dan tanda tangan dari data pribadi

- Kunci publik (32 karakter awal): `dd96c0c087ba57879d96d87302dbfc6a…`
- Alamat Anda: `1c15ee60247352f5659374c4477f4b7ce30e8999`
- Transaksi: kirim **18** ke TEMAN_A
- Tanda tangan: `617441b156c50f12a4d3324135d3613d7c60f8ba59ac4758…`
- Tanda tangan selalu sama saat diulang: True
- Transaksi sah: **True**; setelah amount diubah: **False**
- Penipu memakai alamat Anda: tanda tangannya valid dengan kuncinya = True, transaksinya sah = **False**

## Level 8 — Jaringan dan fork pribadi

- Jumlah node: **5**; blok pribadi tiap node: [3, 1, 2, 3, 2]
- Panjang rantai saat fork: [5, 3, 4, 5, 4]
- Setelah resolve_conflicts: [5, 5, 5, 5, 5], sepakat = **False**
- Setelah blok pemecah seri: [6, 6, 6, 6, 6], sepakat = **True**
- Pemenang fork: **VARADILLA-1**; blok terbuang (orphan): **8**
- Hash ujung rantai: `0057c666e3dc743259566728…`

## Level 9 — Ekonomi dengan halving

- Hadiah awal: **22**, halving setiap **4** blok
- Hadiah blok 1–6 (Modifikasi 9): **22, 22, 22, 22, 11, 11**

| Alamat | Saldo |
|---|---|
| VARADILLA NAISYA ATTAMIMI | 62 |
| TEMAN_A | 29 |
| TEMAN_B | 19 |

- Total suplai: **110**
- Belanja melebihi saldo ditolak: True
- Validasi ekonomi: **True**; setelah hadiah blok 1 dicurangi: **False**

## Analisis (isi dengan kata-kata Anda sendiri)

1. **Level 6.** Bandingkan kolom Percobaan dengan Teori 16^d pada tabel Anda. Mengapa bisa berbeda jauh? Lalu jelaskan jejak difficulty Anda (1, 2, 3, 3, 4, 3, 4, 5): pada langkah mana difficulty naik, tetap, dan turun, dan mengapa?

   _Jawaban:_Hasil percobaan mining tidak selalu sama dengan nilai teori (16^d) karena nilai teori merupakan rata-rata atau ekspektasi matematis, bukan jumlah percobaan yang pasti terjadi pada setiap proses mining. SHA-256 menghasilkan hash yang sulit diprediksi, sehingga jumlah percobaan sampai menemukan hash dengan awalan nol yang sesuai dapat berbeda-beda. Pada hasil saya, difficulty 2 membutuhkan 590 percobaan, lebih banyak daripada nilai teori 256. Sementara itu, difficulty 3 membutuhkan 3.290 percobaan, lebih sedikit daripada nilai teori 4.096. Perbedaan ini wajar karena hasil mining dipengaruhi oleh keluaran hash yang ditemukan.

Pada jejak difficulty, nilai awal adalah 1 dengan target waktu 10 detik. Aturannya adalah difficulty naik jika waktu aktual kurang dari 5 detik, turun jika lebih dari 20 detik, dan tetap jika berada di antara 5 sampai 20 detik. Pada waktu 8 detik, difficulty tetap 1. Pada waktu 0 dan 4 detik, difficulty naik menjadi 2 lalu 3. Pada waktu 8 detik berikutnya, difficulty tetap 3. Waktu 4 detik membuatnya naik menjadi 4. Ketika waktu mencapai 32 detik, difficulty turun menjadi 3. Dua waktu berikutnya, yaitu 4 dan 4 detik, membuat difficulty naik kembali menjadi 4 dan 5. Penyesuaian ini bertujuan menjaga waktu mining agar mendekati waktu target.

2. **Level 7.** Mengapa tanda tangan Anda selalu sama setiap kali program dijalankan, padahal di Level 7 asli berubah-ubah? Mengapa transaksi penipu tidak sah walaupun tanda tangannya valid?

   _Jawaban:_Tanda tangan digital saya selalu sama ketika program dijalankan berulang kali karena menggunakan metode sign_deterministic() berdasarkan standar RFC 6979. Metode ini menghasilkan nilai tanda tangan yang konsisten apabila pesan transaksi dan kunci privatnya sama. Berbeda dengan fungsi sign() pada Level 7 asli yang menggunakan nilai acak sehingga tanda tangan dapat berubah walaupun transaksi dan kuncinya sama.

Transaksi penipu tidak sah walaupun tanda tangannya valid dengan kunci milik penipu sendiri. Hal ini karena tanda tangan digital hanya membuktikan bahwa transaksi ditandatangani oleh pemilik kunci privat yang sesuai. Sistem juga memeriksa apakah alamat pengirim cocok dengan alamat yang berasal dari kunci publik tersebut. Karena penipu menggunakan alamat saya tetapi menandatangani transaksi dengan kuncinya sendiri, alamat pengirim tidak cocok dengan kunci publik penipu. Oleh karena itu, transaksi tetap ditolak.

3. **Keamanan kunci.** Kunci privat Anda dibuat dari nama, NIM, dan tanggal lahir. Mengapa cara ini SANGAT BERBAHAYA di dunia nyata? Siapa saja yang bisa mencuri dana alamat Anda? (Cari tahu istilah *brain wallet*.)

   _Jawaban:_Pembuatan kunci privat dari nama, NIM, dan tanggal lahir sangat berbahaya karena informasi tersebut bukan rahasia yang cukup kuat. Data pribadi dapat diketahui oleh teman, keluarga, orang yang mengenal saya, atau pihak lain melalui media sosial, dokumen, dan kebocoran data. Jika seseorang mengetahui nama, NIM, dan tanggal lahir saya, orang tersebut dapat menghitung ulang hash dan memperoleh kunci privat yang sama.

Cara ini berkaitan dengan istilah brain wallet, yaitu metode membuat kunci atau akses dompet kripto berdasarkan informasi atau kata-kata yang mudah diingat manusia. Jika informasi yang digunakan mudah ditebak atau diketahui orang lain, dompet menjadi rentan diserang. Siapa pun yang berhasil memperoleh kunci privat dapat membuat tanda tangan transaksi seolah-olah sebagai pemilik dan berpotensi memindahkan dana tanpa izin. Karena itu, kunci privat di dunia nyata harus dibuat menggunakan metode kriptografi yang aman dan sumber keacakan yang kuat, bukan dari data pribadi.

4. **Level 8.** Jaringan Anda punya 5 node dan pemenangnya VARADILLA-1 dengan 8 blok terbuang. Jelaskan mengapa node itu menang. Mengapa jaringan Anda sempat tidak sepakat, dan bagaimana blok pemecah seri menyelesaikannya?

   _Jawaban:_Jaringan saya terdiri dari 5 node dengan jumlah blok pribadi masing-masing 3, 1, 2, 3, dan 2. Ketika terjadi fork, panjang rantainya adalah 5, 3, 4, 5, dan 4 blok. Node VARADILLA-1 menjadi salah satu node yang memiliki rantai terpanjang, yaitu 5 blok. Pada kondisi awal terdapat dua node yang memiliki panjang rantai sama, sehingga jaringan belum dapat mencapai kesepakatan hanya dengan memilih rantai terpanjang.

Setelah proses resolve_conflicts, semua node memiliki rantai sepanjang 5 blok, tetapi hasilnya belum sama persis. Hal ini terjadi karena rantai yang memiliki panjang sama dapat memiliki isi blok dan hash yang berbeda. Akibatnya, masih terdapat perbedaan pilihan rantai di antara node.

Setelah blok pemecah seri ditambahkan pada rantai pemenang, panjang rantainya menjadi 6 blok dan lebih panjang daripada rantai lainnya. Node kemudian mengikuti rantai valid terpanjang tersebut sehingga seluruh node memiliki rantai yang sama. Sebanyak 8 blok dari cabang yang kalah menjadi blok terbuang (orphan blocks) karena tidak termasuk dalam rantai utama yang akhirnya disepakati. 
5. **Level 9.** Dengan hadiah awal 22 dan halving setiap 4 blok, berapa batas total suplai jika mining berjalan selamanya? Tunjukkan perhitungannya, lalu kaitkan dengan batas 21 juta Bitcoin.

   _Jawaban:_Berdasarkan program saya, hadiah awal mining adalah 22 koin dan halving dilakukan setiap 4 blok. Karena perhitungan hadiah menggunakan pembagian bilangan bulat (//), urutan hadiah per blok adalah 22, 11, 5, 2, 1, kemudian 0. Artinya, setiap nilai hadiah berlaku selama 4 blok.

Perhitungan total suplai maksimalnya adalah:

Blok 1–4: 4 × 22 = 88 koin.

Blok 5–8: 4 × 11 = 44 koin.

Blok 9–12: 4 × 5 = 20 koin.

Blok 13–16: 4 × 2 = 8 koin.

Blok 17–20: 4 × 1 = 4 koin.

Blok 21 dan seterusnya: hadiah menjadi 0 koin.

Jadi, total suplai maksimal adalah 88 + 44 + 20 + 8 + 4 = 164 koin.

Hasil tersebut berbeda dengan total suplai pada Bitcoin, tetapi menggunakan prinsip yang sama, yaitu hadiah mining dikurangi secara berkala melalui mekanisme halving. Bitcoin memberikan hadiah awal 50 BTC dan mengurangi hadiah menjadi setengah setiap 210.000 blok atau sekitar empat tahun. Mekanisme tersebut membuat jumlah Bitcoin baru yang beredar semakin sedikit dan menghasilkan batas suplai yang dikenal sebesar 21 juta BTC. Perhitungan Bitcoin juga menggunakan satuan terkecil, yaitu satoshi, sehingga pembagian hadiah yang tidak bulat dipotong. Dengan demikian, simulasi saya menunjukkan bagaimana halving dapat membatasi jumlah koin yang diciptakan melalui mining. 

---

## Data verifikasi (JANGAN DIUBAH)

<!-- DATA-VERIFIKASI -->
```json
{
  "tugas": "personal-2 (Level 6-9)",
  "profil": {
    "nama": "VARADILLA NAISYA ATTAMIMI",
    "nim4": "2012",
    "tanggal_lahir": "2005-11-18",
    "kota_asal": "Sorong",
    "hobi": "Berenang"
  },
  "level6": {
    "data_ditambang": "VARADILLA NAISYA ATTAMIMI|2012|2005-11-18",
    "mining": [
      {
        "difficulty": 1,
        "nonce": 15,
        "hash": "048c4d3a260d3933d25ea722f14fe7dda1a518f755475edc2973111dd67d0aae",
        "percobaan": 16,
        "teori": 16
      },
      {
        "difficulty": 2,
        "nonce": 589,
        "hash": "00b2fef71937cb9f9604ec0ad6d54544cf0db7b7cc41dc51b5cb3a31ce7875de",
        "percobaan": 590,
        "teori": 256
      },
      {
        "difficulty": 3,
        "nonce": 3289,
        "hash": "0008e4f826d69c7b16e3774ce551a74cb7dd60936567608873dabe70becb7f95",
        "percobaan": 3290,
        "teori": 4096
      },
      {
        "difficulty": 4,
        "nonce": 71860,
        "hash": "00007a1e7f360c77dfbd49d3777176e258975e57db29b89d7322ea461d1f9978",
        "percobaan": 71861,
        "teori": 65536
      }
    ],
    "difficulty_awal": 1,
    "daftar_waktu_detik": [
      8,
      0,
      4,
      8,
      4,
      32,
      4,
      4
    ],
    "target_detik": 10,
    "jejak_difficulty": [
      1,
      2,
      3,
      3,
      4,
      3,
      4,
      5
    ]
  },
  "level7": {
    "kunci_publik_awal": "dd96c0c087ba57879d96d87302dbfc6a",
    "alamat": "1c15ee60247352f5659374c4477f4b7ce30e8999",
    "transaksi": {
      "sender": "1c15ee60247352f5659374c4477f4b7ce30e8999",
      "recipient": "TEMAN_A",
      "amount": 18
    },
    "tanda_tangan": "617441b156c50f12a4d3324135d3613d7c60f8ba59ac4758fb032359c9a4fa8dfd8ad65f67bdfed97089c5e1ce75c12faefedbc60ee09f40e050bac649de68a5",
    "tanda_tangan_selalu_sama": true,
    "sah": true,
    "sah_setelah_amount_diubah": false,
    "ttd_penipu_valid_dengan_kuncinya": true,
    "transaksi_penipu_sah": false
  },
  "level8": {
    "jumlah_node": 5,
    "blok_pribadi_per_node": [
      3,
      1,
      2,
      3,
      2
    ],
    "panjang_saat_fork": [
      5,
      3,
      4,
      5,
      4
    ],
    "panjang_setelah_resolve": [
      5,
      5,
      5,
      5,
      5
    ],
    "sepakat_setelah_resolve": false,
    "perlu_pemecah_seri": true,
    "panjang_setelah_pemecah_seri": [
      6,
      6,
      6,
      6,
      6
    ],
    "sepakat_setelah_pemecah_seri": true,
    "pemenang_fork": "VARADILLA-1",
    "blok_terbuang": 8,
    "hash_ujung": "0057c666e3dc7432595667284cc8c8cfe738c54db0793be1e396c7a640fd6977"
  },
  "level9": {
    "hadiah_awal": 22,
    "interval_halving": 4,
    "hadiah_per_blok": [
      22,
      22,
      22,
      22,
      11,
      11
    ],
    "saldo": {
      "VARADILLA NAISYA ATTAMIMI": 62,
      "TEMAN_A": 29,
      "TEMAN_B": 19
    },
    "total_suplai": 110,
    "belanja_melebihi_saldo_ditolak": true,
    "validasi_ekonomi": true,
    "hash_ujung": "004aceae0506d24ecd47b702acdba9401e4f93484645ba2f2934fddce8a8edac",
    "validasi_setelah_hadiah_dicurangi": false
  },
  "kode_verifikasi": "5EC227ED0432"
}
```
