
"""
TUGAS PERSONAL — Lima Modifikasi Level 1–5
==========================================

Setiap fungsi/kelas di bawah memodifikasi kode level sebelumnya
agar menggunakan data pribadi mahasiswa.

Jalankan:
python tugas_personal/jalankan_tugas.py
"""

import level01_hash as L1
import level02_blok as L2
import level03_tampering as L3
import level05_pow_nonce as L5


# ============================================================== MODIFIKASI 1
# Level 1: Sidik Jari Mahasiswa

def sidik_jari(nama: str, nim4: str, tanggal_lahir: str) -> str:
    """
    ID mahasiswa = 8 karakter pertama dari SHA-256
    berdasarkan format NIM:NAMA:TANGGAL_LAHIR.
    """

    return L1.sha256_hex(
        f"{nim4}:{nama}:{tanggal_lahir}"
    )[:8]


# ============================================================== MODIFIKASI 2
# Level 2: Blockchain Personal

class BlockchainPersonal(L2.Blockchain):
    """
    Blockchain Level 2 yang dipersonalisasi.

    - Proof blok genesis = int(nim4)
    - Setiap blok memiliki field tambahan "pemilik"
    """

    def __init__(
        self,
        nim4: str,
        id_mhs: str,
        difficulty: int = 4
    ):
        # Inisialisasi blockchain secara manual
        self.difficulty = difficulty
        self.id_mhs = id_mhs
        self.chain = []

        # Membuat blok genesis dengan proof berdasarkan NIM
        self.create_block(
            proof=int(nim4),
            previous_hash="0"
        )

    def create_block(
        self,
        proof: int,
        previous_hash: str
    ) -> dict:
        # Membuat blok menggunakan kelas induk
        block = super().create_block(
            proof,
            previous_hash
        )

        # Menambahkan identitas pemilik
        block["pemilik"] = self.id_mhs

        return block


# ============================================================== MODIFIKASI 3
# Level 3: Simulasi Pemalsuan Blockchain

def palsukan(chain: list, posisi: int):
    """
    Melakukan simulasi pemalsuan blockchain.

    1. Mengubah data blok pada posisi tertentu.
    2. Menambahkan teks (DIPALSUKAN).
    3. Menyambungkan ulang rantai setelah blok tersebut.
    4. Mengembalikan tuple (palsu, disambung).

    Rantai asli tidak boleh berubah.
    """

    # Mengambil data dari blok yang akan dipalsukan
    data_palsu = (
        chain[posisi]["data"] + " (DIPALSUKAN)"
    )

    # Membuat salinan rantai dengan blok yang diubah
    palsu = L3.ubah_blok(
        chain,
        posisi,
        "data",
        data_palsu
    )

    # Menyambungkan ulang blockchain
    disambung = L3.sambung_ulang(
        palsu,
        posisi + 1
    )

    return palsu, disambung


# ============================================================== MODIFIKASI 4
# Level 4: Ringkasan Saldo Mahasiswa

def ringkasan_saldo(bc, nama: str) -> dict:
    """
    Menghitung ringkasan transaksi mahasiswa.

    - masuk  : Total amount yang diterima.
    - keluar : Total amount yang dikirim.
    - bersih : Masuk dikurangi keluar.
    """

    masuk = 0
    keluar = 0

    # Mengambil riwayat transaksi mahasiswa
    for _, tx in bc.riwayat(nama):

        # Menghitung transaksi yang diterima
        if tx["recipient"] == nama:
            masuk += tx["amount"]

        # Menghitung transaksi yang dikirim
        if tx["sender"] == nama:
            keluar += tx["amount"]

    # Mengembalikan ringkasan saldo
    return {
        "masuk": masuk,
        "keluar": keluar,
        "bersih": masuk - keluar
    }


# ============================================================== MODIFIKASI 5
# Level 5: Blockchain Deterministik

class BlockchainDeterministik(L5.Blockchain):
    """
    Blockchain Level 5 tanpa menggunakan jam komputer.

    Timestamp blok genesis menggunakan tanggal lahir mahasiswa.

    Timestamp blok berikutnya menggunakan format:
    YYYY-MM-DD #INDEX
    """

    def __init__(
        self,
        tanggal_lahir: str,
        id_mhs: str,
        difficulty: int = 4
    ):
        # Inisialisasi atribut blockchain
        self.difficulty = difficulty
        self.tanggal_lahir = tanggal_lahir
        self.id_mhs = id_mhs
        self.chain = []

        # Membuat blok genesis secara deterministik
        genesis = {
            "index": 0,
            "timestamp": self.tanggal_lahir,
            "transactions": [
                f"GENESIS {self.id_mhs}"
            ],
            "previous_hash": "0" * 64,
            "nonce": 0
        }

        # Melakukan Proof of Work pada blok genesis
        self.proof_of_work(genesis)

        # Memasukkan blok genesis ke blockchain
        self.chain.append(genesis)

    def new_block(self, transactions: list) -> dict:
        """
        Membuat blok baru dengan timestamp deterministik.
        """

        # Menentukan index blok
        index = len(self.chain)

        # Mengambil hash blok sebelumnya
        previous_hash = self.chain[-1]["hash"]

        # Membuat blok baru
        block = {
            "index": index,
            "timestamp": f"{self.tanggal_lahir} #{index}",
            "transactions": list(transactions),
            "previous_hash": previous_hash,
            "nonce": 0
        }

        # Melakukan Proof of Work
        self.proof_of_work(block)

        # Menambahkan blok ke blockchain
        self.chain.append(block)

        return block
