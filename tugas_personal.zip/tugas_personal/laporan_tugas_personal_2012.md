# Laporan Tugas Personal Blockchain Level 1–5

- **Nama:** VARADILLA NAISYA ATTAMIMI
- **NIM (4 digit terakhir):** 2012
- **Dibuat:** 2026-11-14 17:27  (waktu proses 3.8 detik)
- **Kode verifikasi:** `2D69D467CCDB`

> Bagian hasil dibuat otomatis. Jangan diubah: dosen menghitung ulang semua angka dari data Anda.
> Isi bagian **Analisis** dengan kata-kata Anda sendiri.

## Level 1 — Hash data pribadi

| Hasil | Nilai |
|---|---|
| SHA-256 nama | `8fc3e6a3f0428f28c9c0b34c372d2ebf39c0a61f6f8661493b64c0c82adf0c83` |
| hash_dict profil | `d0626daf5ac592acea6f4ada7fcbb30298643de689dd584dd276f3e91c89e1ff` |
| hash_dict profil (urutan key dibalik) | `d0626daf5ac592acea6f4ada7fcbb30298643de689dd584dd276f3e91c89e1ff` |
| Bit berubah: tanggal lahir vs tanggal lahir + 1 hari | 51.17% |
| ID mahasiswa (Modifikasi 1) | `aed09dda` |

## Level 2 — Blockchain personal

- Proof genesis: **2012** (dari NIM)
- Proof blok 2, 3, 4: **2222, 47312, 26086**
- Pemilik setiap blok: `aed09dda`
- Rantai valid: True

## Level 3 — Pemalsuan data pribadi

- Posisi yang dipalsukan: **1**
- Data asli: `VARADILLA NAISYA ATTAMIMI lahir 2005-11-18`
- Data palsu: `VARADILLA NAISYA ATTAMIMI lahir 2005-11-18 (DIPALSUKAN)`
- Valid sebelum dipalsukan: True
- Tautan putus di indeks: **2**
- Valid setelah dipalsukan: **False**
- Valid setelah disambung ulang: **True**

## Level 4 — Transaksi dari data pribadi

| Blok | Pengirim | Penerima | Jumlah |
|---|---|---|---|
| 2 | VARADILLA NAISYA ATTAMIMI | TEMAN_A | 18 |
| 2 | TEMAN_A | VARADILLA NAISYA ATTAMIMI | 11 |
| 3 | VARADILLA NAISYA ATTAMIMI | DOSEN | 13 |

- Ringkasan saldo (Modifikasi 4): masuk **11**, keluar **31**, bersih **-20**
- Kirim ke diri sendiri ditolak: True
- Amount 0 ditolak: True

## Level 5 — Proof of Work dengan nonce (deterministik)

| Blok | Nonce | Hash |
|---|---|---|
| 0 | 24832 | `0000454cc561e92a2169f219…` |
| 1 | 36525 | `00008a6613703573403583ee…` |
| 2 | 57656 | `0000e722efddfd35ff3adc6a…` |
| 3 | 21096 | `0000feb9ec242e074d1bb68f…` |

- Valid: True → setelah blok 1 dipalsukan: **False**
- Percobaan hash untuk menambang ulang blok 1–3: **294.702**
- Valid setelah ditambang ulang: True

## Analisis (isi dengan kata-kata Anda sendiri)

1. **Level 1.** Bandingkan SHA-256 nama Anda dengan milik seorang teman. Apakah ada pola yang mirip? Jelaskan juga mengapa dua hash profil Anda sama, dan mengapa hanya menambah 1 hari pada tanggal lahir mengubah 51.17% bit.

   _Jawaban:_ Berdasarkan hasil percobaan, SHA-256 nama saya menghasilkan hash 8fc3e6a3..., sedangkan hash milik teman kemungkinan memiliki nilai yang berbeda meskipun nama yang digunakan memiliki beberapa karakter yang sama. Hal ini karena SHA-256 menghasilkan hash berdasarkan keseluruhan isi data, sehingga perubahan satu karakter saja dapat menghasilkan hash yang berbeda. Kedua hash profil saya tetap sama meskipun urutan key dibalik karena fungsi hash_dict mengurutkan key terlebih dahulu sebelum melakukan hashing. Dengan demikian, susunan data tidak memengaruhi hasil hash. Sementara itu, perubahan tanggal lahir sebanyak satu hari menghasilkan perubahan 51,17% bit karena SHA-256 memiliki sifat avalanche effect, yaitu perubahan kecil pada input dapat menyebabkan perubahan besar pada hasil hash.

2. **Level 2.** Kode Anda dan teman sama persis, tetapi proof Anda (2222, 47312, 26086) berbeda. Jelaskan penyebabnya.

   _Jawaban:_Meskipun kode program yang digunakan sama, proof yang dihasilkan dapat berbeda karena setiap mahasiswa menggunakan data pribadi yang berbeda, terutama empat digit terakhir NIM sebagai proof pada blok genesis. Pada blockchain saya, proof genesis menggunakan angka 2012. Perbedaan proof genesis tersebut menyebabkan nilai hash blok menjadi berbeda. Karena setiap blok menyimpan hash dari blok sebelumnya, perubahan pada blok awal juga memengaruhi proses pembentukan blok berikutnya. Oleh karena itu, proof blok 2, 3, dan 4 saya menghasilkan angka 2222, 47312, dan 26086. Hal ini menunjukkan bahwa blockchain dapat menghasilkan rantai yang berbeda meskipun menggunakan algoritma dan struktur kode yang sama, karena data awal yang digunakan berbeda.

3. **Level 3.** Anda memalsukan posisi 1 dan tautan putus terdeteksi di indeks 2, sedangkan valid setelah dipalsukan = False. Jelaskan hasil ini, lalu bandingkan dengan teman yang posisi pemalsuannya berbeda.

   _Jawaban:_Pada percobaan ini, saya melakukan pemalsuan terhadap blok pada posisi 1 dengan menambahkan teks "(DIPALSUKAN)" pada data asli. Sebelum dilakukan pemalsuan, blockchain memiliki status valid karena seluruh hash dan hubungan antarblok masih sesuai. Setelah data blok 1 diubah, hash blok tersebut ikut berubah sehingga tidak lagi sesuai dengan nilai hash yang tersimpan pada blok berikutnya. Akibatnya, tautan blockchain terputus dan terdeteksi pada indeks 2, sehingga status valid menjadi False. Setelah dilakukan penyambungan ulang (relink) mulai dari indeks 2, hash blok berikutnya dihitung kembali agar sesuai dengan perubahan sebelumnya. Hasilnya, blockchain kembali memiliki status valid True. Jika dibandingkan dengan teman yang memalsukan posisi berbeda, letak tautan yang terputus juga dapat berbeda sesuai posisi blok yang diubah. Percobaan ini membuktikan bahwa perubahan data pada satu blok dapat memengaruhi validitas blok-blok berikutnya.


4. **Level 4.** Jelaskan dari mana angka masuk 11, keluar 31, dan bersih -20 berasal. Mengapa transaksi ke diri sendiri perlu ditolak?

   _Jawaban:_Berdasarkan riwayat transaksi, jumlah uang yang masuk ke akun saya berasal dari transaksi TEMAN_A sebesar 11. Sementara itu, jumlah uang yang keluar berasal dari dua transaksi, yaitu pengiriman kepada TEMAN_A sebesar 18 dan kepada DOSEN sebesar 13. Oleh karena itu, total uang keluar adalah 18 + 13 = 31. Saldo bersih diperoleh dari total uang masuk dikurangi total uang keluar, yaitu 11 - 31 = -20. Nilai negatif menunjukkan bahwa jumlah uang yang saya kirim lebih besar daripada jumlah uang yang saya terima sebesar 20. Transaksi ke diri sendiri perlu ditolak karena tidak menunjukkan perpindahan nilai yang sebenarnya dan dapat menyebabkan pencatatan transaksi menjadi tidak relevan. Selain itu, penolakan transaksi dengan jumlah 0 juga diperlukan agar blockchain hanya mencatat transaksi yang memiliki nilai perpindahan uang yang nyata. Dengan demikian, pencatatan transaksi menjadi lebih jelas dan konsisten.

5. **Level 5.** Penyerang butuh 294.702 percobaan hash untuk memalsukan rantai Anda. Mengapa nonce Anda selalu sama setiap kali program dijalankan, padahal di demo Level 5 asli nonce berubah-ubah?

   _Jawaban:_Pada percobaan Level 5, nonce yang dihasilkan selalu sama setiap kali program dijalankan karena blockchain deterministik menggunakan data awal yang tetap, seperti tanggal lahir, ID mahasiswa, transaksi, hash blok sebelumnya, dan nilai awal nonce. Proses Proof of Work dilakukan dengan mencoba nilai nonce secara berurutan sampai menghasilkan hash yang memenuhi tingkat kesulitan (difficulty) yang ditentukan. Karena seluruh input dan proses perhitungannya sama, hasil nonce dan hash yang diperoleh juga akan sama setiap kali program dijalankan. Hal ini berbeda dengan demo Level 5 asli yang menggunakan waktu komputer sebagai timestamp, sehingga waktu yang berubah dapat menyebabkan hash dan nonce yang dihasilkan berbeda. Pada percobaan saya, penyerang membutuhkan 294.702 percobaan hash untuk menambang ulang blok 1 sampai 3 setelah terjadi pemalsuan. Hasil ini menunjukkan bahwa Proof of Work membutuhkan proses komputasi untuk menghasilkan hash yang valid dan membantu menjaga integritas data blockchain.

6. **Etika data.** Anda baru saja menyimpan nama dan tanggal lahir di dalam blockchain. Jika ini blockchain publik, apa risikonya? Kaitkan dengan sifat immutability dan UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi, terutama hak untuk menghapus data.

   _Jawaban:_Menyimpan nama lengkap dan tanggal lahir secara langsung di dalam blockchain publik memiliki risiko terhadap keamanan dan privasi data pribadi. Hal ini karena blockchain memiliki sifat immutability, yaitu data yang sudah dimasukkan ke dalam rantai blok sangat sulit untuk diubah atau dihapus. Apabila data pribadi sudah tersimpan dan dapat diakses oleh publik, orang lain berpotensi memperoleh dan menyalahgunakannya untuk pencurian identitas, penipuan, maupun tindakan lain yang merugikan pemilik data. Kondisi tersebut juga berkaitan dengan Undang-Undang Nomor 27 Tahun 2022 tentang Pelindungan Data Pribadi (UU PDP). Dalam Pasal 8, setiap subjek data pribadi memiliki hak untuk mengakhiri pemrosesan, menghapus, dan/atau memusnahkan data pribadinya sesuai ketentuan peraturan perundang-undangan. Selain itu, Pasal 43 mengatur kewajiban pengendali data untuk menghapus data pribadi dalam kondisi tertentu, termasuk apabila terdapat permintaan dari subjek data. Hal ini menjadi tantangan bagi blockchain publik karena data yang sudah tercatat tidak mudah dihapus secara permanen. Oleh karena itu, menurut saya, data pribadi seperti nama lengkap dan tanggal lahir sebaiknya tidak disimpan secara langsung di blockchain publik. Sebagai alternatif, data pribadi dapat disimpan di luar blockchain (off-chain), sedangkan blockchain hanya menyimpan hash atau referensi data yang tidak mengungkapkan informasi pribadi secara langsung. Dengan cara tersebut, keamanan dan privasi pengguna dapat lebih terjaga tanpa menghilangkan manfaat teknologi blockchain.

---

## Data verifikasi (JANGAN DIUBAH)

<!-- DATA-VERIFIKASI -->
```json
{
  "profil": {
    "nama": "VARADILLA NAISYA ATTAMIMI",
    "nim4": "2012",
    "tanggal_lahir": "2005-11-18",
    "kota_asal": "Sorong",
    "hobi": "Berenang"
  },
  "level1": {
    "hash_nama": "8fc3e6a3f0428f28c9c0b34c372d2ebf39c0a61f6f8661493b64c0c82adf0c83",
    "hash_profil": "d0626daf5ac592acea6f4ada7fcbb30298643de689dd584dd276f3e91c89e1ff",
    "hash_profil_urutan_terbalik": "d0626daf5ac592acea6f4ada7fcbb30298643de689dd584dd276f3e91c89e1ff",
    "avalanche_tanggal_persen": 51.17,
    "id_mahasiswa": "aed09dda"
  },
  "level2": {
    "proof_genesis": 2012,
    "proof_blok": [
      2222,
      47312,
      26086
    ],
    "pemilik_semua_blok": [
      "aed09dda"
    ],
    "valid": true
  },
  "level3": {
    "posisi_dipalsukan": 1,
    "data_asli": "VARADILLA NAISYA ATTAMIMI lahir 2005-11-18",
    "data_palsu": "VARADILLA NAISYA ATTAMIMI lahir 2005-11-18 (DIPALSUKAN)",
    "valid_asli": true,
    "tautan_putus_di": 2,
    "valid_setelah_dipalsukan": false,
    "valid_setelah_disambung_ulang": true
  },
  "level4": {
    "riwayat": [
      [
        2,
        {
          "sender": "VARADILLA NAISYA ATTAMIMI",
          "recipient": "TEMAN_A",
          "amount": 18
        }
      ],
      [
        2,
        {
          "sender": "TEMAN_A",
          "recipient": "VARADILLA NAISYA ATTAMIMI",
          "amount": 11
        }
      ],
      [
        3,
        {
          "sender": "VARADILLA NAISYA ATTAMIMI",
          "recipient": "DOSEN",
          "amount": 13
        }
      ]
    ],
    "ringkasan_saldo": {
      "masuk": 11,
      "keluar": 31,
      "bersih": -20
    },
    "kirim_ke_diri_sendiri_ditolak": true,
    "amount_nol_ditolak": true,
    "jumlah_blok": 3
  },
  "level5": {
    "nonce": [
      24832,
      36525,
      57656,
      21096
    ],
    "hash": [
      "0000454cc561e92a2169f219fecff93c1ad7bc95cc37e9f9d820110e2bd6c624",
      "00008a6613703573403583ee2510a29735e2965822f1d629d196a6f47b9665e4",
      "0000e722efddfd35ff3adc6a716158b7c90ad2100a1b7fd4f187cea9462452e8",
      "0000feb9ec242e074d1bb68f08e239daf2dc2bb99f4c74cf070733bc4c74619b"
    ],
    "valid": true,
    "valid_setelah_dipalsukan": false,
    "percobaan_tambang_ulang": 294702,
    "valid_setelah_tambang_ulang": true
  },
  "kode_verifikasi": "2D69D467CCDB"
}
```
