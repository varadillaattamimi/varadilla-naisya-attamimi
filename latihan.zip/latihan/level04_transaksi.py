
"""
LEVEL 4 — Menambahkan Transaksi ke dalam Blok (LATIHAN)
=============================================================

Blok di artikel GfG tidak berisi data apa pun. Di sini kita menambahkan
mempool (daftar transaksi tertunda) yang akan dimasukkan ke blok saat mining.

Tujuan belajar:
  * Konsep transaksi tertunda (pending / mempool).
  * Validasi input transaksi.
  * Menelusuri riwayat transaksi di seluruh rantai.

Jalankan tes: python cek_nilai.py 4
"""

import datetime
import hashlib
import json


class Blockchain:
    def __init__(self, difficulty: int = 3):
        self.difficulty = difficulty
        self.chain = []
        self.pending_transactions = []
        self.create_block(proof=1, previous_hash="0")

    # ---------- SUDAH DISEDIAKAN ----------
    def hash(self, block):
        return hashlib.sha256(
            json.dumps(block, sort_keys=True).encode()
        ).hexdigest()

    def valid_proof(self, previous_proof, proof):
        h = hashlib.sha256(
            str(proof**2 - previous_proof**2).encode()
        ).hexdigest()
        return h.startswith("0" * self.difficulty)

    def proof_of_work(self, previous_proof):
        proof = 1
        while not self.valid_proof(previous_proof, proof):
            proof += 1
        return proof

    def last_block(self):
        return self.chain[-1]

    # ---------- BAGIAN YANG DIKERJAKAN ----------

    def create_block(self, proof: int, previous_hash: str) -> dict:
        """Membuat blok baru yang berisi transaksi tertunda."""

        block = {
            "index": len(self.chain) + 1,
            "timestamp": str(datetime.datetime.now()),
            "transactions": list(self.pending_transactions),
            "proof": proof,
            "previous_hash": previous_hash,
        }

        self.chain.append(block)

        # Kosongkan transaksi setelah dimasukkan ke blok
        self.pending_transactions.clear()

        return block

    def add_transaction(self, sender: str, recipient: str, amount) -> int:
        """Menambahkan transaksi ke daftar transaksi tertunda."""

        # Memeriksa sender dan recipient
        if not isinstance(sender, str) or not sender.strip():
            raise ValueError("Sender harus berupa string dan tidak boleh kosong")

        if not isinstance(recipient, str) or not recipient.strip():
            raise ValueError("Recipient harus berupa string dan tidak boleh kosong")

        # Sender tidak boleh sama dengan recipient
        if sender == recipient:
            raise ValueError("Sender dan recipient tidak boleh sama")

        # Amount harus berupa angka, bukan boolean, dan lebih dari nol
        if (
            isinstance(amount, bool)
            or not isinstance(amount, (int, float))
            or amount <= 0
        ):
            raise ValueError("Amount harus berupa angka lebih dari 0")

        transaksi = {
            "sender": sender,
            "recipient": recipient,
            "amount": amount,
        }

        self.pending_transactions.append(transaksi)

        # Mengembalikan index blok yang akan memuat transaksi
        return self.last_block()["index"] + 1

    def mine_block(self) -> dict:
        """Menambang blok baru yang berisi semua transaksi tertunda."""

        previous_block = self.last_block()

        previous_proof = previous_block["proof"]

        proof = self.proof_of_work(previous_proof)

        previous_hash = self.hash(previous_block)

        block = self.create_block(proof, previous_hash)

        return block

    def riwayat(self, nama: str) -> list:
        """Menampilkan riwayat transaksi berdasarkan nama."""

        hasil = []

        for block in self.chain:
            for tx in block["transactions"]:
                if (
                    tx["sender"] == nama
                    or tx["recipient"] == nama
                ):
                    hasil.append((block["index"], tx))

        return hasil


if __name__ == "__main__":
    bc = Blockchain()

    bc.add_transaction("Ani", "Budi", 5)
    bc.add_transaction("Budi", "Citra", 2)

    bc.mine_block()

    bc.add_transaction("Citra", "Ani", 1)

    bc.mine_block()

    print(json.dumps(bc.chain, indent=2))
    print("Riwayat Budi:", bc.riwayat("Budi"))
