"""
LEVEL 7 — Kunci Publik/Privat dan Tanda Tangan Digital (LATIHAN)
======================================================================

Di level sebelumnya siapa pun bisa menulis transaksi atas nama orang lain.
Sekarang setiap transaksi harus ditandatangani dengan kunci privat pengirim.
Kurva yang dipakai: SECP256k1 (kurva yang sama dengan Bitcoin dan Ethereum).

Butuh library:  pip install ecdsa

Tujuan belajar:
  * Pasangan kunci privat/publik dan alamat (address).
  * Menandatangani dan memverifikasi transaksi.
  * Mengapa transaksi yang diubah setelah ditandatangani menjadi tidak sah.

Jalankan tes:  python cek_nilai.py 7
"""

import hashlib
import json

from ecdsa import BadSignatureError, SECP256k1, SigningKey, VerifyingKey


def buat_pasangan_kunci():
    """Membuat pasangan kunci privat dan publik."""
    sk = SigningKey.generate(curve=SECP256k1)
    vk = sk.get_verifying_key()

    kunci_privat_hex = sk.to_string().hex()
    kunci_publik_hex = vk.to_string().hex()

    return kunci_privat_hex, kunci_publik_hex


def alamat_dari_kunci_publik(kunci_publik_hex: str) -> str:
    """Membuat alamat dari 40 karakter pertama hash SHA-256 kunci publik."""
    data = bytes.fromhex(kunci_publik_hex)
    hasil_hash = hashlib.sha256(data).hexdigest()

    return hasil_hash[:40]


def pesan_transaksi(tx: dict) -> bytes:
    """Mengubah data transaksi menjadi bytes secara kanonik."""
    data = {
        "sender": tx["sender"],
        "recipient": tx["recipient"],
        "amount": tx["amount"]
    }

    return json.dumps(
        data,
        sort_keys=True
    ).encode("utf-8")


def tanda_tangani(tx: dict, kunci_privat_hex: str) -> str:
    """Menandatangani transaksi menggunakan kunci privat."""
    sk = SigningKey.from_string(
        bytes.fromhex(kunci_privat_hex),
        curve=SECP256k1
    )

    pesan = pesan_transaksi(tx)
    tanda_tangan = sk.sign(pesan)

    return tanda_tangan.hex()


def verifikasi(
    tx: dict,
    tanda_tangan_hex: str,
    kunci_publik_hex: str
) -> bool:
    """Memeriksa apakah tanda tangan transaksi valid."""
    try:
        vk = VerifyingKey.from_string(
            bytes.fromhex(kunci_publik_hex),
            curve=SECP256k1
        )

        tanda_tangan = bytes.fromhex(tanda_tangan_hex)
        pesan = pesan_transaksi(tx)

        return vk.verify(tanda_tangan, pesan)

    except (BadSignatureError, ValueError, TypeError):
        return False


def transaksi_sah(
    tx: dict,
    tanda_tangan_hex: str,
    kunci_publik_hex: str
) -> bool:
    """Memeriksa tanda tangan dan kecocokan alamat pengirim."""
    try:
        alamat = alamat_dari_kunci_publik(kunci_publik_hex)

        if tx.get("sender") != alamat:
            return False

        return verifikasi(
            tx,
            tanda_tangan_hex,
            kunci_publik_hex
        )

    except (ValueError, TypeError, KeyError):
        return False


if __name__ == "__main__":
    priv, pub = buat_pasangan_kunci()

    alamat = alamat_dari_kunci_publik(pub)

    tx = {
        "sender": alamat,
        "recipient": "alamat_budi",
        "amount": 5
    }

    sig = tanda_tangani(tx, priv)

    print("Alamat Ani :", alamat)
    print("Tanda tangan:", sig[:32], "...")
    print("Sah?", transaksi_sah(tx, sig, pub))

    tx["amount"] = 500

    print(
        "Setelah amount diubah jadi 500, sah?",
        transaksi_sah(tx, sig, pub)
    )
